oXygen Modifications
--------------------
The content of this folder represents the DITA Open Toolkit without the following directories:

tools
doc